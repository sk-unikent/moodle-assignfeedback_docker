#
# My first assignment!
# University is so exciting!
#

#
# This function should return the sum of both arguments.
#
def add(first, second):
	return first + second

#
# This function should return the difference between both arguments.
#
def subtract(first, second):
	return first - second
